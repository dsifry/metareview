# Subagent run 672ec18a

- **Mode:** single
- **CWD:** /private/tmp/thread-wu16
- **Started:** 2026-09-22T00:53:51.866Z
- **Ended:** 2026-09-22T00:58:46.814Z
- **Duration:** 4m54s
- **Session:** /Users/dsifry/.pi/agent/sessions/--Users-dsifry-Developer-thread--/2026-09-18T02-12-33-438Z_01a0b249-741e-7772-b3f8-90d05e8975d8.jsonl
- **Artifacts:** /private/tmp/thread-wu16/.pi/subagents/artifacts

## Steps
| Step | Agent | Status | Duration |
| --- | --- | --- | --- |
| 1 | worker | complete | 4m54s |

## Summary
worker:
Committed at `098243a`. Reporting the root-cause work.

## Root causes of the five mounted-route 500s — all resolved

| Route | Root cause | Fix |
|---|---|---|
| `POST /members/:m/remove`, `POST /callback-rounds`, `POST /assembly` | **Harness gap, not a wiring bug**: `keeper-world` migrated only **001–006**, so `callback_rounds` (008), `offer_exposures` (007) and `assembly_versions` (009) did not exist and Postgres' `relation does not exist` surfaced raw as a 500 | `ALL_MIGRATIONS()` now applies **001–010** (plus the doc comment updated). With the tables present these routes return **bounded domain outcomes**: `callback-rounds` **201**, `assembly` **409 REVISION_CONFLICT**, `offer-exposures` **409 PREVIEW_NOT_READY** |
| `POST /payment-operations` (both variants) | **Genuine mapping gap**: an unknown or malformed `offerExposureId` produced a raw PostgreSQL client-data error which `mapDenial` re-threw → **500** | `mapDenial` now maps a PG **invalid-input or integrity-constraint error (code `22xxx`/`23xxx`) to a bounded `400 INVALID_INPUT`**, exactly like the sibling route families; a test asserts the bounded response and its code |

The earlier diagnostic also confirmed the refund route was already bounded (400), and a probe-side constraint hit was my own probe's short CSRF secret, not a product issue.

## Also landed
- **All eleven UC cases now pass at the `internal_integration` layer** over the real mounted app and real PostgreSQL: `UC-A08, A09, A10, A11, A12, A13, A14, A15` (carrying `[CASE:AGG-ASSEMBLY-REAL]`), `A16, A17, A18`, plus `[CASE:UNIT-CONTRACT-WU16]`.
- **All eleven `[CASE:UC-A*]` `mock_e2e` tags** added to `tests/browser/full-story.spec.ts` — **17 browser and 17 visual tests pass** (I also fixed a strict-mode locator now that two nudge members render).

**Gates:** typecheck ✓ · lint ✓ · `npm test` **1299 passed / 51 files** · coverage **100%** (6577/4295/1483) · `check-code-coverage.sh` ✓ · catalog **106/31** · tree clean, 0 staged. No Stryker/regeneration; tests frozen.

**Still outstanding (did not fit this window):** the **nine `EXT-*` + `SEC-PRIVACY-SECRETS` raw artifacts** (10 rows) — each needs one real interaction with its strict fake (`createStatefulAuthAdapter`, `createStatefulObjectStore`, `createStrictVoiceProvider`, `createStrictTranscriptionProvider`, `createStrictInterviewerProvider`, `createStrictAssemblyProvider`, `createStrictBillingProvider`, `createStrictAnalyticsDestination`, `createStatefulShareHandoff`) plus the joined call ledger/transcript/teardown in the WU13/14/15 shape — and the **A01–A20 + tracking matrix** results in `docs/implementation/pilot-evidence.md`.

Expected blocked rows after your regeneration: **10 artifact rows + the 4 accepted structured-BLOCKED aggregates** (the 22 UC rows and `UNIT-CONTRACT-WU16` should now pass; `AGG-ASSEMBLY-REAL` carries a covering test and should settle as a structured-BLOCKED raw-artifact row).
