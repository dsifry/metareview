Sweep finished. Here is the verbatim result.

**`DONE WU16 full_wu16` line:**
```
[05:28:34] DONE WU16 full_wu16 exit=1 :: WU16 mutation: 12786/15660 killed, waived=2846, unresolved=[survived], unwaived=[ignored:1649,ignored:1650,ignored:1651,ignored:1652,ignored:1653,ignored:1654,ignored:1655,ignored:1656,ignored:1657,ignored:1658,ignored:1659,ignored:1660,ignored:1661,ignored:1662,ignored:1663,ignored:1664,ignored:1665,ignored:1666,ignored:1667,ignored:1668,ignored:1669,ignored:1670]
```

**LEDGER:**
```
[05:28:35] LEDGER write exit=1
[05:28:35] LEDGER check exit=1
```
No "Mutation ledger written/in sync" line was emitted (the write throws before printing). The error body is:
```
Error: Survivors without a reviewed equivalence proof (review them; do not waive):
WU12 apps/server/src/routes/billing.ts:194:10 ConditionalExpression (replacement "true")
WU12 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/(22P02|23503)$/u")
WU12 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/^(22P02|23503)/u")
WU16 apps/server/src/routes/billing.ts:194:10 ConditionalExpression (replacement "true")
WU16 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/(22P02|23503)$/u")
WU16 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/^(22P02|23503)/u")
```

**VERIFY lines (verbatim):**
```
[05:29:12] VERIFY WU01 exit=0 :: WU01 verification: 8 pass, 0 fail, 0 blocked.
[05:29:52] VERIFY WU02 exit=0 :: WU02 verification: 26 pass, 0 fail, 0 blocked.
[05:30:39] VERIFY WU03 exit=0 :: WU03 verification: 31 pass, 0 fail, 0 blocked.
[05:31:34] VERIFY WU04 exit=0 :: WU04 verification: 39 pass, 0 fail, 0 blocked.
[05:32:13] VERIFY WU05 exit=0 :: WU05 verification: 43 pass, 0 fail, 0 blocked.
[05:32:51] VERIFY WU06 exit=0 :: WU06 verification: 71 pass, 0 fail, 0 blocked.
[05:33:29] VERIFY WU07 exit=1 :: VERIFICATION_FAILED: WU07 verification: 8 pass, 0 fail, 1 blocked.
[05:34:08] VERIFY WU08 exit=0 :: WU08 verification: 75 pass, 0 fail, 0 blocked.
[05:34:47] VERIFY WU09 exit=1 :: VERIFICATION_FAILED: WU09 verification: 80 pass, 0 fail, 1 blocked.
[05:35:25] VERIFY WU10 exit=1 :: VERIFICATION_FAILED: WU10 verification: 85 pass, 0 fail, 1 blocked.
[05:36:04] VERIFY WU11 exit=1 :: VERIFICATION_FAILED: WU11 verification: 95 pass, 0 fail, 3 blocked.
[05:36:43] VERIFY WU12 exit=1 :: VERIFICATION_FAILED: WU12 verification: 100 pass, 1 fail, 2 blocked.
[05:37:20] VERIFY WU13 exit=1 :: VERIFICATION_FAILED: WU13 verification: 103 pass, 1 fail, 2 blocked.
[05:37:58] VERIFY WU14 exit=1 :: VERIFICATION_FAILED: WU14 verification: 108 pass, 1 fail, 2 blocked.
[05:38:35] VERIFY WU15 exit=1 :: VERIFICATION_FAILED: WU15 verification: 113 pass, 1 fail, 2 blocked.
[05:39:13] VERIFY WU16 exit=1 :: VERIFICATION_FAILED: WU16 verification: 136 pass, 2 fail, 4 blocked.
```

**ALL-DONE reached: YES** — `[05:39:13] ALL-DONE` (process 98487 now gone).

**Failure analysis (from the fresh manifests):**
- `reports/verification/WU16.evidence.json` non-pass records: `MUT-WU12-FOCUSED` (fail), `MUT-WU16-FULL` (fail), and the 4 expected structured BLOCKED rows (`AGG-INTERVIEWER-REAL`, `AGG-ASSEMBLY-REAL`, `AGG-VOICE-FEASIBILITY-REAL`, `AGG-REAL-BROWSER-PROVIDER-DEVICE`).
- `reports/verification/WU12.evidence.json` non-pass records: `MUT-WU12-FOCUSED` (fail), `AGG-INTERVIEWER-REAL` + `AGG-VOICE-FEASIBILITY-REAL` (blocked). WU13/14/15's single fail is the same WU12-focused mutation row propagated through the dependency row.
- Root cause: the rewritten `isClientDataError` (`apps/server/src/routes/billing.ts:193-197`) has 3 unproofed survivors in the WU12-focused and WU16-full reports — the `typeof code === 'string' && /^(22P02|23503)$/` gate and the two regex boundary mutants. Everything else (WU01–WU11, WU06-full, WU11-full) is 0 unresolved; WU12's 3 previously-known stale-binding proofs did carry on rebuild.