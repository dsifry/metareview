# Task for worker

You are a delegated subagent running from a fork of the parent session. Treat the inherited conversation as reference-only context, not a live thread to continue. Do not continue or answer prior messages as if they are waiting for a reply. Your sole job is to execute the task below and return a focused result for that task using your tools.

Task:
Implement the CORE dev-runnable runtime for WU17 of the Keeper MVP. TypeScript/React/Fastify/Postgres monorepo.
ALL edits under the absolute path /Users/dsifry/Developer/thread-wu17 (branch wu17-devrun, base 528070a, node_modules installed). Run every command after `cd /Users/dsifry/Developer/thread-wu17`. Do NOT touch any other worktree.

READ FIRST (do not change them): tests/helpers/migrations.ts (the canonical migration applier: pg_advisory_xact_lock, per-file transaction, schema_migrations ledger with sha256, digest-mismatch is a hard failure), migrations/001_kernel.sql .. 010_delivery.sql, apps/server/src/main.ts (createKeeperServer, createDisabledAuthAdapter ~line 868, readServerEnvironment, installGracefulShutdown), apps/server/src/adapters/auth.ts, packages/contracts/src/invitations.ts (AuthAdapter interface), packages/domain/src/invitations.ts (startAccountChallenge ~1255, completeAccountChallenge ~1335; sessions are inserted with columns id, principal_id, token_digest (64 hex), csrf_secret (>=16 chars), expires_at).

DELIVERABLE 1 — bin/migrate.mjs + package.json script "db:migrate".
Standalone Node ESM script. Read DATABASE_URL from env; exit(1) with a clear message when missing or unreachable. Discover migrations/*.sql in lexical order, create schema_migrations if absent, apply each unapplied file inside a transaction under pg_advisory_xact_lock(8274119003421), record path+sha256, SKIP already-applied files whose digest matches, FAIL on digest mismatch. Rerun must be a no-op. Print a short summary. Use the `pg` Client. Mirror tests/helpers/migrations.ts semantics exactly.

DELIVERABLE 2 — bin/seed-dev.mjs + package.json script "db:seed".
Standalone ESM script. Refuse unless KEEPER_ENV === 'development' (exit 1 otherwise). Idempotently upsert one owner principal, one story, and one open invitation (and, if straightforward, a callback/assembly row) via SQL against DATABASE_URL. Use deterministic UUIDs so a rerun does not duplicate rows (INSERT ... ON CONFLICT DO NOTHING / DO UPDATE). Print the seeded ids.

DELIVERABLE 3 — dev session mint path usable in a browser, gated to KEEPER_ENV=development.
Add `createDevelopmentAuthAdapter()` in apps/server/src/main.ts next to createDisabledAuthAdapter(): start() returns a deterministic providerReference, verify() returns {verified:true, reason:null}. Export it. Then wire the `dev:server` package.json script so that when KEEPER_ENV === 'development' it selects createDevelopmentAuthAdapter(), and otherwise (prod/test) it keeps createDisabledAuthAdapter(). Also make bin/seed-dev.mjs mint a real sessions row for the seeded owner principal and print the `keeper_session=<token>` cookie value plus the CSRF secret, so a human can attach it. Keep all existing behavior for test/prod untouched. If the login flow requires an initiating session, document that plainly in the runbook instead of weakening auth.

DELIVERABLE 4 — LOCAL-RUNBOOK.md at the repo root: prereqs (Node, Postgres, this repo), export DATABASE_URL, KEEPER_ENV=development, KEEPER_RETENTION_NOTICE_VERSION=1.0.0, storage roots, then `npm run db:migrate`, `npm run db:seed`, `npm run dev:server`, `npm run dev:worker`, `npm run dev:web`, the URL(s) to open and the ?surface= URLs to click, and an explicit list of BLOCKED paths (real voice/device capture, real interviewer/assembly models, real billing/delivery) with the exact resumption condition. Never suggest faking a pass.

DELIVERABLE 5 — update .env.example and SERVICE-INVENTORY.md to match what you add (KEEPER_ENV=development, db:migrate/db:seed, dev auth/session, storage roots). Change KEEPER_PAYMENT_ENDPOINT to an .invalid host so accidental live targeting is impossible.

DELIVERABLE 6 — tests to the project's 100% coverage bar. Add tests under tests/unit or tests/integration in the existing style, against the real test database: export KEEPER_ENV=test NODE_ENV=test DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:55432/keeper_test KEEPER_RETENTION_NOTICE_VERSION=1.0.0. Cover: migrate a fresh schema (all 10 applied), rerun no-op, missing DATABASE_URL exits non-zero, migration digest mismatch fails, seed creates owner/story/invitation, seed rerun is idempotent, seed refuses outside KEEPER_ENV=development, the dev auth adapter verifies and is refused/not-selected outside development. Import the CLIs as modules where possible or spawn them; do not just assert on strings.

HARD CONSTRAINTS: TypeScript strict, no `any`; do not weaken existing tests/coverage/lint; no real provider calls/spend/sends/ads; fakes stay refused outside KEEPER_ENV=test; anything needing credentials is named BLOCKED, never faked; do not edit docs/implementation/keeper-test-strategy.json or the decomposition (catalog stays 106/31).

RUN AND REPORT from /Users/dsifry/Developer/thread-wu17: `npm run typecheck`, `npm run lint`, `npx vitest run <new tests>`, `npm run test:coverage` (must remain 100% statements/branches/functions/lines). Also prove the CLIs on a scratch DB: createdb, run migrate twice and seed twice, show the second runs are no-ops.

RETURN: files added/changed; exact commands with observed output/exit codes; coverage numbers; any blocker you could not satisfy (named, never faked). Work autonomously to completion — implement, test, and run the gates; do not stop at a plan.

## Acceptance Contract
Acceptance level: checked
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Implement the requested change without widening scope
- criterion-2: Return evidence sufficient for an independent acceptance review

Required evidence: changed-files, tests-added, commands-run, residual-risks, no-staged-files

Review gate: required by reviewer.

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    },
    {
      "id": "criterion-2",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```