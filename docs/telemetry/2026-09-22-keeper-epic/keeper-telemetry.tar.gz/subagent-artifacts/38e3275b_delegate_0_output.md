Subagent run failed before producing output.

Error:
400: {"code":"UPSTREAM_ERROR","message":"Upstream provider error"}

Transcript: /Users/dsifry/Developer/thread/.pi/subagents/artifacts/38e3275b_delegate_0_transcript.jsonl
Metadata: /Users/dsifry/Developer/thread/.pi/subagents/artifacts/38e3275b_delegate_0_meta.json