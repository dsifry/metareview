# Task for delegate

Implement the CORE runtime of WU17 (dev-runnable local service) for the Keeper MVP.
WORKTREE — make ALL edits under this absolute path: /Users/dsifry/Developer/thread-wu17  (branch wu17-devrun, base 528070a, node_modules installed).
Do NOT edit /Users/dsifry/Developer/thread (main) or /Users/dsifry/Developer/thread-wu16. Run every command with `cd /Users/dsifry/Developer/thread-wu17` first.

CONTEXT
TypeScript/React/Fastify/Postgres monorepo. The MVP is fully verified but cannot be started locally: migrations exist only in tests/helpers/migrations.ts, apps/server/src/main.ts uses createDisabledAuthAdapter() so AuthAdapter.start/verify throw, there is no seed data, and navigation is query-driven (?surface=...).
Migrations live in migrations/001_kernel.sql .. 010_delivery.sql. Read tests/helpers/migrations.ts first and mirror its apply semantics (ordered, each in a transaction, recorded in a ledger) in a standalone CLI.
Read apps/server/src/main.ts (createKeeperServer, createDisabledAuthAdapter, readServerEnvironment, installGracefulShutdown), packages/domain/src/database.ts (createKernel), and the sessions table in migrations/001_kernel.sql before writing the dev auth adapter.

DELIVERABLES
1. bin/migrate.mjs + npm script `db:migrate`: read DATABASE_URL; apply migrations/00N_*.sql in order; create a schema_migrations ledger table; skip already-applied migrations; each migration in a transaction; fail closed (non-zero exit + clear message) when DATABASE_URL is missing/unreachable or a migration fails. Rerun is a no-op.
2. bin/seed-dev.mjs + npm script `db:seed`: ONLY when KEEPER_ENV=development (refuse otherwise, non-zero exit); idempotently seed an owner principal, one story, and one open invitation (optionally a callback/assembly row) using the domain APIs/kernel where they exist. Rerun must not duplicate rows.
3. Add createDevelopmentAuthAdapter() (or a documented session-mint helper) in the server code, usable ONLY when KEEPER_ENV=development, that mints a real row in the sessions table for a seeded principal and verifies it; wire `dev:server` so that under KEEPER_ENV=development it uses the development adapter instead of the disabled one. Production/test behavior unchanged.
4. LOCAL-RUNBOOK.md at the repo root: exact commands (Postgres + DATABASE_URL, KEEPER_ENV=development, KEEPER_RETENTION_NOTICE_VERSION=1.0.0, storage roots, db:migrate, db:seed, dev:server/dev:worker/dev:web), the ?surface= URLs to click, and the explicitly BLOCKED paths (real voice/device, real interviewer/assembly models, real billing/delivery) with resumption conditions. Never instruct faking a pass.
5. Update .env.example and SERVICE-INVENTORY.md to match (KEEPER_ENV=development, DB scripts, dev auth, storage roots); set KEEPER_PAYMENT_ENDPOINT to an .invalid host so accidental live targeting is impossible.
6. Tests at the project's 100% coverage bar (statements/branches/functions/lines) for the new code, against the real PostgreSQL test database exactly like existing tests: KEEPER_ENV=test NODE_ENV=test DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:55432/keeper_test. Assert real behavior: migrate a fresh schema, rerun no-op, missing DATABASE_URL fails, seed idempotency, seed refuses outside development, dev auth mints+verifies a session and is refused outside development.

HARD CONSTRAINTS
- TypeScript strict, no `any`. TDD where practical.
- Do not weaken or bypass existing tests/coverage/lint/verifier.
- No real provider calls/spend/sends/ads; fakes stay refused outside KEEPER_ENV=test; anything needing credentials is named BLOCKED, never faked.
- Keep the catalog at 106 cases / 31 decisions (do not edit the strategy JSON).

COMMANDS TO RUN AND REPORT (from /Users/dsifry/Developer/thread-wu17 with KEEPER_ENV=test NODE_ENV=test DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:55432/keeper_test KEEPER_RETENTION_NOTICE_VERSION=1.0.0):
  npm run typecheck
  npm run lint
  npx vitest run <the tests you added>
  npm run test:coverage   (must stay 100%)
Also prove the CLIs against a scratch database: create a fresh DB, run `KEEPER_ENV=development DATABASE_URL=<scratch> node bin/migrate.mjs` twice and `node bin/seed-dev.mjs` twice, showing the second run is a no-op.

RETURN: files added/changed, exact commands with observed output/exit codes, coverage numbers, and any blocker you could not satisfy (named, never faked). Work autonomously to completion; do not stop at a plan.

## Acceptance Contract
Acceptance level: checked
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Implement the requested change without widening scope
- criterion-2: Return evidence sufficient for an independent acceptance review

Required evidence: changed-files, tests-added, commands-run, residual-risks, no-staged-files

Review gate: required by reviewer.

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    },
    {
      "id": "criterion-2",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```