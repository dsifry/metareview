## Watch result

**ALL-DONE reached 01:40:11**; process `34261` exited cleanly. Full chain summary:

**WU16 full scope**
```
[01:30:15] DONE WU16 full_wu16 exit=1
  WU16 mutation: 12789/15660 killed, waived=2846, unresolved=[survived],
  unwaived=[ignored:1649 … ignored:1670]  (22 ids)
```

**Ledger**
```
[01:30:15] LEDGER write  exit=0
   "Mutation ledger written: 2871 unique waivers (381 proven_equivalent, 2490 static; 39 carried across a pure line shift) from 18 report(s)."
[01:30:16] LEDGER check  exit=1   ← immediately after a successful write
    Error: The mutation-waiver ledger is not in sync with the raw mutation reports.
```
Reproduced 2/2 on re-run → **deterministic**, i.e. regeneration is not a fixed point (write output ≠ re-derivation from that output).

**Verify (all 16)**
```
WU01 exit=0   8 pass /0 fail/0 blocked
WU02 exit=0  26 /0/0
WU03 exit=0  31 /0/0
WU04 exit=0  39 /0/0
WU05 exit=0  43 /0/0
WU06 exit=1  70 /1/0   fail=AGG-REAL-BROWSER-PROVIDER-DEVICE
WU07 exit=1   8 /0/1   blocked=1
WU08 exit=1  74 /1/0
WU09 exit=1  79 /1/1
WU10 exit=1  84 /1/1
WU11 exit=1  94 /2/2   fails=INT-FREE-MILESTONE, AGG-REAL-BROWSER-PROVIDER-DEVICE
                       blocked=AGG-INTERVIEWER-REAL, AGG-VOICE-FEASIBILITY-REAL
WU12 exit=1 100 /1/2
WU13 exit=1 103 /1/2
WU14 exit=1 108 /1/2
WU15 exit=1 113 /1/2
WU16 exit=1  EVIDENCE_SCHEMA_INVALID
```

**Root cause (one command clears the whole cascade):** `npm test` is red —
`tests/unit/free-browser-aggregate.test.ts:40` → *"The WU06 real-browser aggregate artifact is missing. Run: `npm run test:browser -- --project=mock-e2e tests/browser/free-memory.spec.ts`"*. `reports/raw/WU06-model-device-AGG-REAL-BROWSER-PROVIDER-DEVICE.json` is absent (only the differently-named `WU06-device-…-run.json` exists), so every unit's `AGG-REAL-BROWSER-PROVIDER-DEVICE` row degrades from **blocked → fail** and `INT-FREE-MILESTONE` (WU11) fails too. `reports/` is gitignored, so the /tmp purge/move lost it.

**WU16-specific:** its self-built manifest fails its own schema at `bin/check-keeper-quality.mjs:2200-2201` — records 52–60 (`EXT-ACCOUNT, EXT-STORAGE, EXT-VOICE, EXT-TRANSCRIPTION, EXT-INTERVIEWER, EXT-ASSEMBLY, EXT-BILLING, EXT-DESTINATION, EXT-HANDOFF`) have `details` in the wrong kind/order (`postgres` detail emitted at `details[0]` where the provider-simulator/"port" artifact is required; schema wants `engine/server_version/migration_manifest/…` at `[1]`).