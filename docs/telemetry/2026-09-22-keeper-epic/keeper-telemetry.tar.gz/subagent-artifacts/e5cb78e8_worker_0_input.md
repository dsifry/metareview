# Task for worker

You are a delegated subagent running from a fork of the parent session. Treat the inherited conversation as reference-only context, not a live thread to continue. Do not continue or answer prior messages as if they are waiting for a reply. Your sole job is to execute the task below and return a focused result for that task using your tools.

Task:
You are an independent adversarial reviewer for WU16 (final integration/acceptance) of the Keeper MVP. Worktree: /Users/dsifry/Developer/thread-wu16 (branch wu16-integration, HEAD 15119b9 plus one uncommitted fix). Base of comparison: 019ffa4 (accepted WU01-WU15).
READ-ONLY. Do not edit, commit, or run heavy commands. A mutation sweep is running in this worktree; do not run npm test/stryker.
Inspect: git diff 019ffa4..HEAD -- apps/server/src/main.ts apps/worker/src/main.ts apps/web/src/App.tsx apps/server/src/routes/billing.ts apps/web/src/features/story.tsx tests/unit/full-integration-contracts.test.ts tests/browser/full-story.spec.ts .env.example SERVICE-INVENTORY.md
Also read docs/metareview/work-units/WU16.md and docs/metareview/work-units/WU16-mutation-triage.md.
Look specifically for BLOCKING issues only: (1) any fabricated PASS or claim of real provider/device/billing/delivery evidence that is actually unavailable (these must be named structured BLOCKED); (2) any security/privacy hole (cross-principal media reads, unauthenticated durable mutation, secret leakage into artifacts/logs); (3) evidence-integrity failures, e.g. a test that writes an evidence artifact claiming calls that did not occur, or a waiver/proof that papers over a reachable observable difference; (4) any route mounted without its required auth/CORS/CSRF guard, or a guard that a client can bypass; (5) the ASSEMBLY_COMPOSE_PERSIST_BLOCKER honesty and the isClientDataError -> 400 mapping (can it mask a real internal 500 or accept junk?).
Note for context: the uncommitted fix changes tests/unit/full-integration-contracts.test.ts so the inherited EXT-* evidence artifacts use the schema-valid fakeCall projection (the fakes' raw call objects are not schema-valid) and EXT-ACCOUNT uses port account_recovery. Assess whether that is a legitimate deterministic projection of a real interaction or fabricated evidence.
Report: a numbered list of findings, each with severity (P1 blocking / P2 / advisory), file:line, the concrete evidence (quote the code or artifact), and a recommended action. If you find no blocking issue, say so explicitly and state what you verified to conclude that. Do not speculate without evidence; cite file paths and line numbers.

## Acceptance Contract
Acceptance level: attested
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Return concrete findings with file paths and severity when applicable

Required evidence: review-findings, residual-risks

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```