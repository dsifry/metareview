# Task for worker

You are a delegated subagent running from a fork of the parent session. Treat the inherited conversation as reference-only context, not a live thread to continue. Do not continue or answer prior messages as if they are waiting for a reply. Your sole job is to execute the task below and return a focused result for that task using your tools.

Task:
Implement WU17's local-run smoke test and its negative controls for the Keeper MVP.
ALL edits under /Users/dsifry/Developer/thread-wu17 (branch wu17-devrun). Run every command after `cd /Users/dsifry/Developer/thread-wu17`. Do NOT touch any other worktree. There are uncommitted-ready changes already committed at b03f564; build on top.

DELIVERABLE 1 — bin/verify-local-run.mjs (add npm script "test:local-run": "node bin/verify-local-run.mjs").
A standalone Node ESM script that proves the DOCUMENTED local path actually runs, using REAL processes (never Fastify inject), and exits non-zero on any failure. Steps:
  a. Create a scratch PostgreSQL database (or a scratch schema) from DATABASE_URL; run `bin/migrate.mjs` against it and assert all 10 migrations applied; run it a second time and assert 0 applied (no-op); assert a required table exists (e.g. stories or sessions).
  b. Run `bin/seed-dev.mjs` (KEEPER_ENV=development) against the scratch DB; assert the owner principal, one story, an open invitation and a sessions row exist; run it a second time and assert the row counts are unchanged (idempotent).
  c. Boot the REAL server entrypoint (the same code path `npm run dev:server` uses) and the worker as child processes with KEEPER_ENV=development, KEEPER_RETENTION_NOTICE_VERSION=1.0.0, APP_ORIGIN=http://127.0.0.1:5173 and the scratch DATABASE_URL; poll /health and /ready until 200 (bounded timeout, then fail).
  d. Drive the free two-person journey over real HTTP with the seeded `keeper_session` cookie (and CSRF header): owner memory -> invitation -> second person claims -> friend reply -> free result. Study tests/browser/free-memory.spec.ts and the route files under apps/server/src/routes to find the exact endpoints/commands; assert exact statuses. Also assert an authenticated story read is 200 and the same request without the cookie is 401.
  e. Boundary/negative controls (each must FAIL, i.e. the script detects it): with KEEPER_ENV=development and no provider keys, a real-provider operation returns the NAMED blocked code and never 200; starting the server without KEEPER_RETENTION_NOTICE_VERSION fails closed; running migrate with no DATABASE_URL exits non-zero; running seed outside KEEPER_ENV=development exits non-zero; a request without the dev session 401s. Structure these as explicit checks with clear PASS/FAIL lines.
  f. Print a final summary line and exit 0 only if every check passed. Clean up the child processes and the scratch DB/schema.

DELIVERABLE 2 — a real-browser run (V2): add a Playwright project named `local-run` (in playwright.config.ts) that runs against the live dev stack and the real database (NOT the mock-e2e server), walks the two-context free journey, and captures a screenshot per step. If the existing mock-e2e harness cannot be reused, create a small spec tests/browser/local-run.spec.ts plus a webServer/global-setup that starts the real `dev:server` + `dev:web` (point the API at the scratch DB) — but do NOT duplicate or weaken mock-e2e. If a real-browser run against the live stack is not feasible in this environment, implement it as far as is honest and return the exact blocker (named) rather than faking a pass.

DELIVERABLE 3 — tests for the new bin/verify-local-run.mjs logic at the 100% coverage bar (export its check functions so a test can drive them against the real test database), and keep the whole suite + coverage green.

HARD CONSTRAINTS: TypeScript strict where TS, no `any`; never fake a pass; anything needing credentials/device is a named BLOCKED; do not weaken existing tests/coverage/lint/verifier; do not edit the strategy JSON or decomposition.

RUN AND REPORT from /Users/dsifry/Developer/thread-wu17:
  npm run typecheck ; npm run lint ; npm run test:local-run ; npx vitest run <new tests> ; npm run test:coverage ; bash bin/check-code-coverage.sh
Report the exact output of test:local-run and the coverage numbers.

RETURN: files added/changed; exact commands with observed output/exit codes; whether the real-browser project runs or its named blocker; coverage numbers; any blocker (named, never faked). Work autonomously to completion.

## Acceptance Contract
Acceptance level: checked
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Implement the requested change without widening scope
- criterion-2: Return evidence sufficient for an independent acceptance review

Required evidence: changed-files, tests-added, commands-run, residual-risks, no-staged-files

Review gate: required by reviewer.

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    },
    {
      "id": "criterion-2",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```