**Monitoring complete — `ALL-DONE` reached at `[05:39:13]`, but the WU16 sweep is NOT clean.** All requested lines verbatim, then findings.

### 1. `DONE WU16 full_wu16` line + summary
```
[05:28:34] DONE WU16 full_wu16 exit=1 :: WU16 mutation: 12786/15660 killed, waived=2846, unresolved=[survived], unwaived=[ignored:1649,...,ignored:1670]
```
(22 `ignored` static mutants; `unresolved=[survived]` = 3 survivors, see finding 1)

### 2. LEDGER write / check exit codes + final ledger line
```
[05:28:34] LEDGER write
[05:28:35] LEDGER write exit=1
[05:28:35] LEDGER check
[05:28:35] LEDGER check exit=1
```
**There is no final ledger line** ("Mutation ledger written…" never printed) — both runs threw before writing. Error, verbatim:
```
Error: Survivors without a reviewed equivalence proof (review them; do not waive):
WU12 apps/server/src/routes/billing.ts:194:10 ConditionalExpression (replacement "true")
WU12 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/(22P02|23503)$/u")
WU12 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/^(22P02|23503)/u")
WU16 apps/server/src/routes/billing.ts:194:10 ConditionalExpression (replacement "true")
WU16 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/(22P02|23503)$/u")
WU16 apps/server/src/routes/billing.ts:194:38 Regex (replacement "/^(22P02|23503)/u")
```
Note: the previously-stale `billing.ts:150/153/167` proofs are **not** listed → the identity-carry did re-bind them successfully.

### 3. Every `VERIFY … exit=… :: …` line
```
[05:29:12] VERIFY WU01 exit=0 :: WU01 verification: 8 pass, 0 fail, 0 blocked.
[05:29:52] VERIFY WU02 exit=0 :: WU02 verification: 26 pass, 0 fail, 0 blocked.
[05:30:39] VERIFY WU03 exit=0 :: WU03 verification: 31 pass, 0 fail, 0 blocked.
[05:31:34] VERIFY WU04 exit=0 :: WU04 verification: 39 pass, 0 fail, 0 blocked.
[05:32:13] VERIFY WU05 exit=0 :: WU05 verification: 43 pass, 0 fail, 0 blocked.
[05:32:51] VERIFY WU06 exit=0 :: WU06 verification: 71 pass, 0 fail, 0 blocked.
[05:33:29] VERIFY WU07 exit=1 :: VERIFICATION_FAILED: WU07 verification: 8 pass, 0 fail, 1 blocked.
[05:34:08] VERIFY WU08 exit=0 :: WU08 verification: 75 pass, 0 fail, 0 blocked.
[05:34:47] VERIFY WU09 exit=1 :: VERIFICATION_FAILED: WU09 verification: 80 pass, 0 fail, 1 blocked.
[05:35:25] VERIFY WU10 exit=1 :: VERIFICATION_FAILED: WU10 verification: 85 pass, 0 fail, 1 blocked.
[05:36:04] VERIFY WU11 exit=1 :: VERIFICATION_FAILED: WU11 verification: 95 pass, 0 fail, 3 blocked.
[05:36:43] VERIFY WU12 exit=1 :: VERIFICATION_FAILED: WU12 verification: 100 pass, 1 fail, 2 blocked.
[05:37:20] VERIFY WU13 exit=1 :: VERIFICATION_FAILED: WU13 verification: 103 pass, 1 fail, 2 blocked.
[05:37:58] VERIFY WU14 exit=1 :: VERIFICATION_FAILED: WU14 verification: 108 pass, 1 fail, 2 blocked.
[05:38:35] VERIFY WU15 exit=1 :: VERIFICATION_FAILED: WU15 verification: 113 pass, 1 fail, 2 blocked.
[05:39:13] VERIFY WU16 exit=1 :: VERIFICATION_FAILED: WU16 verification: 136 pass, 2 fail, 4 blocked.
```

### 4. ALL-DONE
**Yes** — `[05:39:13] ALL-DONE` (exactly one occurrence).

### Findings
- **BLOCKER (evidence integrity) — 3 genuinely-observable mutants survive `apps/server/src/routes/billing.ts:194`** (the newly-bounded `isClientDataError`). `unresolved=[survived]`, so the ledger fails closed and cannot be written. I proved these are real reachable differences (pure-JS semantics), i.e. **test gaps, not waivable equivalences**: mutant `typeof code==='string'`→`true` differs on `{code:23503}` (number coerces to a valid code); `/(22P02|23503)$/` differs on `'x23503'`/`'x22P02'`; `/^(22P02|23503)/` differs on `'23503x'`/`'22P02x'`. **Fix: add those 5 reject cases to the predicate test** in `tests/unit/full-integration-contracts.test.ts` (test-only change → another full regeneration).
- **BLOCKER (downstream of the above) — every `fail` row is a mutation record**: `MUT-WU12-FOCUSED` in WU12/WU13/WU14/WU15 (1 each) and `MUT-WU12-FOCUSED` + `MUT-WU16-FULL` in WU16 (2). These fail only because the on-disk ledger lacks the 3 proofs and the write aborted. No non-mutation record fails.
- **GOOD — expected target was mostly met**: no `STALE_*` or `EVIDENCE_SCHEMA_INVALID` anywhere (both earlier defects confirmed fixed). `blocked` rows are exactly the accepted real-provider/device aggregates: WU07 1, WU09 1, WU10 1, WU11 3, WU12–WU15 2 each, WU16 4 (`AGG-INTERVIEWER-REAL`, `AGG-ASSEMBLY-REAL`, `AGG-VOICE-FEASIBILITY-REAL`, `AGG-REAL-BROWSER-PROVIDER-DEVICE`). WU11's 95/0/3 matches its accepted state exactly. WU01–WU06 + WU08 clean, 0 blocked.
- **NOTE**: `full_wu06`/`full_wu11` were clean (0 unresolved); `full_wu16` 12786/15660 killed, and the only unresolved items are the 3 above.

### Residual risks
- Expectation from the parent's brief ("no unit has any fail; only accepted blocked rows") is **not met** for WU12–WU16 until the 3 test cases are added and the tree is regenerated.
- After the fix, another full regeneration (~2.5 h) is required (test-tree hash change), and WU12–WU16 should then converge to 0 fail with blocked-only rows.