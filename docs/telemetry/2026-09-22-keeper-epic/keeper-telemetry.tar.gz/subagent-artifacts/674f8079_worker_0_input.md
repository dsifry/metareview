# Task for worker

You are a delegated subagent running from a fork of the parent session. Treat the inherited conversation as reference-only context, not a live thread to continue. Do not continue or answer prior messages as if they are waiting for a reply. Your sole job is to execute the task below and return a focused result for that task using your tools.

Task:
Monitor /tmp/wu16-bg7.log until it contains a line ending in 'ALL-DONE' (or until process 32736 is gone with no ALL-DONE).
Check every 90 seconds with: tail -3 /tmp/wu16-bg7.log; ps -p 32736
Read-only. Do not edit anything in /Users/dsifry/Developer/thread-wu16.
This is the final WU16 regeneration at HEAD 7d68a8c: 16 focused scopes, then full_wu06/full_wu11/full_wu16, then ledger write/check, then verify WU01..WU16.
When done, report verbatim: every 'DONE ... exit=... :: ...' line; the LEDGER write and check exit codes plus the final 'Mutation ledger written/in sync' line; and every 'VERIFY ... exit=... :: ...' line; plus whether ALL-DONE was reached.
Expected: WU12 focused and WU16 full no longer have any survivor at apps/server/src/routes/billing.ts:194; no unit has any fail; blocked rows only for the accepted real-provider/device aggregates (WU07 1; WU09/WU10 1 each; WU11 3; WU12-WU16 include inherited real aggregates + AGG-ASSEMBLY-REAL).
Do not stop early; this takes ~2.5 hours.

## Acceptance Contract
Acceptance level: attested
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Return concrete findings with file paths and severity when applicable

Required evidence: review-findings, residual-risks

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```