# Task for worker

You are a delegated subagent running from a fork of the parent session. Treat the inherited conversation as reference-only context, not a live thread to continue. Do not continue or answer prior messages as if they are waiting for a reply. Your sole job is to execute the task below and return a focused result for that task using your tools.

Task:
Monitor /tmp/wu16-bg4.log until it contains a line ending in 'ALL-DONE' (or until process 34261 is gone with no ALL-DONE).
Check every 60 seconds with: tail -3 /tmp/wu16-bg4.log; ps -p 34261
Read-only. Do not edit anything.
This runs WU16's two stale full mutation scopes (full_wu11, full_wu16), then ledger write/check, then verify for WU01..WU16.
When done, report: for each full scope the 'DONE <WU> <scope> exit=...' line and the '<WU> mutation: X/Y killed, waived=N, unresolved=[...], unwaived=[...]' summary; the LEDGER write and check exit codes; every VERIFY line with exit code and summary; and whether ALL-DONE was reached.
Do not stop early; this can take up to ~2 hours.

## Acceptance Contract
Acceptance level: attested
Completion is not accepted from prose alone. End with a structured acceptance report.

Criteria:
- criterion-1: Return concrete findings with file paths and severity when applicable

Required evidence: review-findings, residual-risks

Finish with a fenced JSON block tagged `acceptance-report` in this shape:
Use empty arrays when no items apply; array fields contain strings unless object entries are shown.
`criteriaSatisfied[].status` must be exactly one of: satisfied, not-satisfied, not-applicable.
`commandsRun[].result` must be exactly one of: passed, failed, not-run.
`manualNotes` and `notes` are optional strings; an empty string means no note and does not satisfy `manual-notes` evidence.
```acceptance-report
{
  "criteriaSatisfied": [
    {
      "id": "criterion-1",
      "status": "satisfied",
      "evidence": "specific proof"
    }
  ],
  "changedFiles": [
    "src/file.ts"
  ],
  "testsAddedOrUpdated": [
    "test/file.test.ts"
  ],
  "commandsRun": [
    {
      "command": "command",
      "result": "passed",
      "summary": "short result"
    }
  ],
  "validationOutput": [
    "validation output or concise summary"
  ],
  "residualRisks": [
    "none"
  ],
  "noStagedFiles": true,
  "diffSummary": "short description of the diff",
  "reviewFindings": [
    "blocker: file.ts:12 - issue found, or no blockers"
  ],
  "manualNotes": "anything else the parent should know"
}
```